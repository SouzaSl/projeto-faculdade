package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

public class TabAdapter extends FragmentStateAdapter {

    public TabAdapter(@NonNull FragmentActivity fragmentActivity) {
        super(fragmentActivity);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        // Retorna o fragmento correspondente à aba
        switch (position) {
            case 0:
                return new SobreFragment(); // Primeira aba ("Sobre")
            case 1:
                return new OutraAbaFragment(); // Segunda aba
            default:
                return new SobreFragment(); // Caso padrão (para evitar erros)
        }
    }

    @Override
    public int getItemCount() {
        return 2; // Número de abas
    }
}
