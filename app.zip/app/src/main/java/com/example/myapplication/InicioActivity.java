package com.example.myapplication;

import android.os.Bundle;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import androidx.appcompat.app.AppCompatActivity;

public class InicioActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicio);

        // Delay de 3 segundos (3000 ms) antes de ir para a próxima tela
        new Handler().postDelayed(() -> {
            Intent intent = new Intent(InicioActivity.this, MainActivity.class);
            startActivity(intent);
            finish(); // Encerra a Splash Screen para que o usuário não possa voltar
        }, 3000);
    }
}