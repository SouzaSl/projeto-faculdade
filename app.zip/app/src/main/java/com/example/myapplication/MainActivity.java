package com.example.myapplication;

import android.os.Bundle;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.view.View;
import android.widget.Button;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

public class MainActivity extends AppCompatActivity {

    private Fragment OutraAbaFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Habilita a funcionalidade EdgeToEdge
        EdgeToEdge.enable(this);

        setContentView(R.layout.activity_main);

        // Configura a escuta para os insets da janela para aplicar o padding corretamente
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Referência ao botão "Sobre"
        Button btnSobre = findViewById(R.id.btn_sobre);

        // Ação do clique do botão "Sobre"
        btnSobre.setOnClickListener(v -> {
            // Cria uma nova instância do fragmento "Sobre"
            SobreFragment sobreFragment = new SobreFragment();

            // Inicia a transação do fragmento
            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();

            // Substitui o conteúdo atual com o SobreFragment
            transaction.replace(R.id.main, sobreFragment);
            transaction.addToBackStack(null); // Adiciona à pilha de navegação (opcional)
            transaction.commit();
        });

        // Referência ao botão "Outro"
        Button btnOutro = findViewById(R.id.btn_outro);

        // Ação do clique do botão "Outro"
        btnOutro.setOnClickListener(v -> {
            // Cria uma nova instância do fragmento "Outro"
            OutraAbaFragment outraAbaFragment = new OutraAbaFragment();

            // Inicia a transação do fragmento
            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();

            // Substitui o conteúdo atual com o OutroFragment
            transaction.replace(R.id.main, outraAbaFragment);
            transaction.addToBackStack(null); // Adiciona à pilha de navegação (opcional)
            transaction.commit();
        });
    }
}
